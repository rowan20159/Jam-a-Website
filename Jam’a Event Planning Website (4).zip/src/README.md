# Jam'a Landing Page

A modern, responsive landing page for Jam'a - an AI-powered event planning platform.

## Features

- 🎨 **Modern Design**: Clean, professional UI with Jam'a's sage green and coral brand colors
- 📱 **Fully Responsive**: Optimized for all device sizes
- ⚡ **Fast Performance**: Built with Vite for optimal loading speeds
- 🎭 **Smooth Animations**: Powered by Motion/React
- 📝 **Interactive Waitlist**: Complete form validation and user feedback
- ♿ **Accessible**: WCAG compliant with proper ARIA attributes
- 🚀 **Production Ready**: Optimized build for Netlify deployment

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd jama-landing-page
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:5173](http://localhost:5173) in your browser

## Build for Production

```bash
npm run build
```

This creates a `dist/` folder with optimized static assets ready for deployment.

## Deployment on Netlify

### Option 1: Direct Deployment
1. Build the project: `npm run build`
2. Deploy the `dist/` folder to Netlify
3. The site will load correctly with all assets properly referenced

### Option 2: Git-based Deployment (Recommended)
1. Push your code to a Git repository (GitHub, GitLab, etc.)
2. Connect your repository to Netlify
3. Netlify will automatically use the settings from `netlify.toml`:
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Node version: 18

### Troubleshooting
- If you see a blank page, check the browser console for errors
- Ensure all dependencies are installed: `npm install`
- Verify the build works locally: `npm run build && npm run preview`
- Make sure there are no conflicting files in the root directory

## Project Structure

```
src/
├── components/
│   ├── ui/              # Reusable UI components
│   ├── figma/           # Figma-specific components
│   └── WaitlistForm.tsx # Main waitlist modal
├── styles/
│   └── globals.css      # Global styles and Tailwind config
├── App.tsx             # Main application component
└── main.tsx           # Application entry point
```

## Technologies Used

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS v4** - Styling
- **Motion/React** - Animations
- **Radix UI** - Accessible UI primitives
- **Lucide React** - Icons

## Key Components

- **Hero Section**: Eye-catching introduction with CTA
- **How It Works**: 3-step process explanation
- **Features**: Core platform capabilities
- **For Vendors**: Vendor-focused section
- **Team**: Meet the founders
- **Waitlist Form**: Interactive signup modal with validation

## Contact

For questions about this project, please contact the Jam'a team.

---

© 2025 Jam'a. All rights reserved.