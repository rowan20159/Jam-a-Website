
  # Jam’a Event Planning Website

  This is a code bundle for Jam’a Event Planning Website. The original project is available at https://www.figma.com/design/PxfKRVhzURLPhVL25CgQWD/Jam%E2%80%99a-Event-Planning-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  